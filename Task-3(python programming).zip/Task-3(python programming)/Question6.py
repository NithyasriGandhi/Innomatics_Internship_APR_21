A = int(input())
B = int(input())
C = int(input())
D = int(input())

print((A**B)+(C**D))