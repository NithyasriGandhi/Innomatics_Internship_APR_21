
def minion_game(string):
    scores = {"Kevin": 0, "Stuart": 0}
    for i in range(len(string)):
        if string[i] in "AEIOU":
            scores["Kevin"]+=len(string)-i
        else:
            scores["Stuart"]+=len(string)-i
    if scores["Stuart"] == scores["Kevin"]:
        print("Draw")
    elif scores["Stuart"] > scores["Kevin"]:
        print("%s %s" %("Stuart", scores["Stuart"]))
    else:
        print("%s %s" %("Kevin", scores["Kevin"]))
if __name__ == '__main__':
    s = input()
    minion_game(s)

14th Program(Merge the Tools!):

def merge_the_tools(string, k):
    for part in zip(*[iter(string)] * k):
        d = dict()
        print(''.join([ d.setdefault(c, c) for c in part if c not in d ]))

    return 0
if __name__ == '__main__':
    string, k = input(), int(input())
    merge_the_tools(string, k)