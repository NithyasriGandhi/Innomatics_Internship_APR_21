#!/usr/bin/env python
# coding: utf-8

# In[26]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[52]:


df=pd.read_excel(r'C:\Users\Windows 10\Desktop\aspiring_minds_employability_outcomes_2015.xlsx')
print(df)


# In[53]:


df.head() #top 5 records


# In[54]:


df.shape   #Shape of the dataset


# In[55]:


df.info()   #Description of the data


# In[56]:


df.drop(['DOJ','DOB','DOL'],axis=1, inplace=True)
df.head()


# In[57]:


from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()


# In[58]:


df["Gender"]=le.fit_transform(df["Gender"])            #Converting string values to int


# In[59]:



df["Designation"]=le.fit_transform(df["Designation"])


# In[60]:


df["12board"]=df["12board"].replace(0,'cbse')                 #converting column with both string and int to entirely int


# In[61]:


df["JobCity"]=df["JobCity"].replace(-1,'Bangalore')             #converting column with both string and int to entirely intJobCity


# In[62]:


df["10board"]=df["10board"].replace(0,'cbse')             #converting column with both string and int to entirely intJobCity


# In[63]:


df["JobCity"]=le.fit_transform(df["JobCity"])


# In[64]:


df["10board"]=le.fit_transform(df["10board"])


# In[65]:


df["Degree"]=le.fit_transform(df["Degree"])


# In[66]:


df["Specialization"]=le.fit_transform(df["Specialization"])


# In[67]:


df["CollegeState"]=le.fit_transform(df["CollegeState"])


# In[68]:


df["12board"]=le.fit_transform(df["12board"])


# In[69]:


df["Unnamed: 0"]=df["Unnamed: 0"].replace("train",0)


# In[70]:


df.info()     # detailed info


# In[71]:



df.isna().sum().sum()                  # to check nan values


# In[72]:



df.describe()                           # describing data


# In[73]:


#Univariate Analysis


# In[74]:


sns.distplot(df.ID)


# In[75]:



sns.distplot(df.Salary)


# In[76]:


sns.distplot(df["10percentage"])


# In[77]:



sns.distplot(df["12percentage"])


# In[78]:


sns.distplot(df["collegeGPA"])


# In[79]:


sns.distplot(df["CollegeCityID"])


# In[80]:


sns.distplot(df["English"])


# In[81]:


sns.distplot(df["Logical"])


# In[82]:


sns.distplot(df["Domain"])


# In[83]:


sns.distplot(df["conscientiousness"])


# In[84]:



sns.distplot(df["agreeableness"])


# In[85]:



sns.distplot(df["extraversion"])


# In[86]:



sns.distplot(df["openess_to_experience"])


# In[87]:


#
For Categorical Variables


# In[88]:


sns.countplot(df.Gender)


# In[89]:



sns.countplot(df.CollegeTier)


# In[90]:



sns.countplot(df.Specialization)


# In[91]:


sns.countplot(df.CollegeCityTier)


# In[92]:


#Bivariate Analysis


# In[93]:


sns.pairplot(df,vars=['CollegeTier', 'Salary'])


# In[94]:



sns.pairplot(df,vars=['Gender', 'Salary'])


# In[95]:


sns.pairplot(df,vars=['ComputerProgramming', 'Salary'])


# In[96]:


sns.pairplot(df,vars=['collegeGPA', 'Salary'])


# In[97]:


sns.pairplot(df,vars=['Quant', 'Salary'])


# In[98]:


sns.pairplot(df,vars=['Logical', 'Salary'])


# In[99]:


sns.pairplot(df,vars=['English', 'Salary'])


# In[100]:


sns.pairplot(df,vars=['MechanicalEngg', 'Salary'])


# In[101]:


sns.pairplot(df,vars=['ComputerScience', 'Salary'])


# In[102]:



sns.pairplot(df,vars=['CivilEngg', 'Salary'])


# In[103]:


sns.pairplot(df,vars=['TelecomEngg', 'Salary'])


# In[104]:


sns.pairplot(df,vars=['ElectricalEngg', 'Salary'])


# In[105]:



sns.pairplot(df,vars=['Specialization', 'Salary'])


# In[106]:


sns.pairplot(df,vars=['ComputerScience','Salary'])


# In[ ]:


#Conclusion

#We can conclude that the Salary column is mainly affected by columns like Domain, Quant, CollegeGPA, Logical, English, Collegetier, Specialization. There is not much relation with Salary for columns like Gender, 12graduation, 10board,12 board,JobCity, CollegeID

