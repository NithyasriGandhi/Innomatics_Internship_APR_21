eng_num = int(input())
eng_set = set(map(int, input().split()))
fren_num = int(input())
fren_set = set(map(int, input().split()))

print(len(eng_set.difference(fren_set)))