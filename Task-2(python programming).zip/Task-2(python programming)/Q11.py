items = set()
for i in range(int(input())):
    items.add(input())
print(len(items))