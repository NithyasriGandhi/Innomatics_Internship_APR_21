import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm
l = [490, 220, 470, 500, 495, 496, 496, 498, 508, 480]

sum(l)/len(l)
confidence_level = 0.95

alpha = 1 - confidence_level

z_critical = norm.ppf(1 - alpha/2) 

print(z_critical)
sample_size = 10
sample_mean = 465.3
pop_mean = 500
pop_std = 50

z = z_score(sample_size, sample_mean, pop_mean, pop_std)
x_min = 400
x_max = 600
mean = pop_mean
std = pop_std / sample_size**0.5
x = np.linspace(x_min, x_max, 100)
y = norm.pdf(x, mean, std)
plt.xlim(x_min, x_max)
plt.plot(x, y)

z_critical_left = pop_mean + (-z_critical * std)
z_critical_right = pop_mean + (z_critical * std)
x1 = np.linspace(x_min, z_critical_left, 100)
y1 = norm.pdf(x1, mean, std)
plt.fill_between(x1, y1, color='orange')
x2 = np.linspace(z_critical_right, x_max, 100)
y2 = norm.pdf(x2, mean, std)
plt.fill_between(x2, y2, color='orange')
plt.scatter(sample_mean, 0)
plt.annotate("x_bar", (sample_mean, 0.0007)
if(np.abs(z) > z_critical):
    print("Reject Null Hypothesis")
else:
    print("Fail to reject Null Hypothesis"