import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm
n =[4 ,2,5,4,5,3,5,5,4,2,4,5,5,4,4,5,4,5,4,5]
sum(n)/len(n)
confidence_level = 0.95

alpha = 1 - confidence_level

z_critical = norm.ppf(1 - alpha)

print(z_critical)
sample_size = 20
sample_mean = 4.25
pop_mean = 4
pop_std = 0.5
z = z_score(sample_size, sample_mean, pop_mean, pop_std)

print(z)
x_min = 3.5
x_max = 4.5
mean = pop_mean
std = pop_std / (sample_size**0.5)
x = np.linspace(x_min, x_max, 100)
y = norm.pdf(x, mean, std)
plt.xlim(x_min, x_max)
plt.plot(x, y)
z_critical_right = pop_mean + (z_critical * std)
x1 = np.linspace(z_critical_right, x_max, 100)
y1 = norm.pdf(x1, mean, std)
plt.fill_between(x1, y1, color='orange')
plt.scatter(sample_mean, 0)
plt.annotate("x_bar", (sample_mean, 0.1))
if(z > z_critical):
    print("Reject Null Hypothesis")
else:
    print("Fail to reject Null Hypothesis")