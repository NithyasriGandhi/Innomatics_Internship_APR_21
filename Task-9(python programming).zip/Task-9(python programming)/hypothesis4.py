
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm
confidence_level = 0.95
alpha = 1 - 0.99

z_critical = norm.ppf(1 - alpha)

print(z_critical)

sample_size = 100
sample_mean = 97.5
pop_mean = 100
pop_std = 10
z = z_score(sample_size, sample_mean, pop_mean, pop_std)

print(z)
x_min = 95
x_max = 105

mean = pop_mean
std = pop_std / (sample_size**0.5)

x = np.linspace(x_min, x_max, 100)
y = norm.pdf(x, mean, std)

plt.xlim(x_min, x_max)
# plt.ylim(0, 0.03)

plt.plot(x, y)

z_critical_left = pop_mean + (-z_critical * std)

x1 = np.linspace(x_min, z_critical_left, 100)
y1 = norm.pdf(x1, mean, std)
plt.fill_between(x1, y1, color='orange')

plt.scatter(sample_mean, 0)
plt.annotate("x_bar", (sample_mean, 0.02))
if(z < -z_critical):
    print("Reject Null Hypothesis")
else:
    print("Fail to reject Null Hypothesis")