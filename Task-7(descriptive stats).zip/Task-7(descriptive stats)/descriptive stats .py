import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
data=pd.read_csv('/content/data.csv')
data.head()
data.mean()
data.median()
data.mode()
data.var()
data.std()
data.corr()
sns.distplot(data['Annual_HH_Income'])
from google.colab import drive
from scipy.special import ndtri
df=data.sort_values(by=['Annual_HH_Income'],ascending=True).reset_index()

df['count']=df.index+1
df.head()
n_rows=df.shape[0]

df['percentile_area']=(df['count'])/n_rows
df['z_theoritical']=ndtri(df['percentile_area'])
df['z_actual']=(df['Annual_HH_Income'] - df['Annual_HH_Income'].mean())/df['Annual_HH_Income'].std(ddof=0)

df.head()
plt.scatter(df.z_actual,df.z_theoritical)
plt.plot([-2,-1,0,1,2],[-2,-1,0,1,2])

data.describe()
data=data.drop('Emi_or_Rent_Amt',axis=1)

data=data.drop('Highest_Qualified_Member',axis=1)

data.head()

%matplotlib inline
from sklearn.preprocessing import PowerTransformer

def plots(d,var,t):
  plt.figure(figsize=(13,5))
  plt.subplot(121)
  sns.kdeplot(d[var])
  plt.title('beforee'+str(t).split(' ')[0])

  plt.subplot(122)
  p1=t.fit_transform(d[[var]]).flatten()
  sns.kdeplot(p1)
  plt.title('after'+str(t).split('(')[0])
for col in data.columns:
  plots(data,col,PowerTransformer(method='box-cox'))

#MEAN
The arithmetic mean, or simply the mean or the average, is the sum of a collection of numbers divided by the count of numbers in the collection. The collection is often a set of results of an experiment or an observational study, or frequently a set of results from a survey.

It is easy to calculate: add up all the numbers, then divide by how many numbers there are. In other words it is the sum divided by the count.


#MEDIAN
The median is the middle number in a sorted, ascending or descending, list of numbers and can be more descriptive of that data set than the average.

how to calculate median??
Arrange your numbers in numerical order.

Count how many numbers you have.

If you have an odd number, divide by 2 and round up to get the position of the median number.

If you have an even number, divide by 2. Go to the number in that position and average it with the number in the next higher position to get the median.
MODE:
The mode is the value that appears most frequently in a data set. A set of data may have one mode, more than one mode, or no mode at all. Other popular measures of central tendency include the mean, or the average of a set, and the median, the middle value in a set.

VARIANCE
The variance is a measure of variability. It is calculated by taking the average of squared deviations from the mean.

Variance tells you the degree of spread in your data set. The more spread the data, the larger the variance is in relation to the mean.

#STANDARD DEVIATION
A standard deviation is a statistic that measures the dispersion of a dataset relative to its mean. The standard deviation is calculated as the square root of variance by determining each data point's deviation relative to the mean. If the data points are further from the mean, there is a higher deviation within the data set; thus, the more spread out the data, the higher the standard deviation.

CORRELATION
“Correlation” is a statistical term describing the degree to which two variables move in coordination with one-another. If the two variables move in the same direction, then those variables are said to have a positive correlation. If they move in opposite directions, then they have a negative correlation.

NORMAL DISTRIBUTION
Normal distribution, also known as the Gaussian distribution, is a probability distribution that is symmetric about the mean, showing that data near the mean are more frequent in occurrence than data far from the mean. In graph form, normal distribution will appear as a bell curve

FEATURES OF NORMAL DISTRIBUTION
The mean, mode and median are all equal. The curve is symmetric at the center (i.e. around the mean, μ).

Exactly half of the values are to the left of center and exactly half the values are to the right.

The total area under the curve is 1.

POSITIVELY  & NEGATIVELY SKEWED NORMAL DISTRIBUTION:

A right-skewed distribution has a long right tail. Right-skewed distributions are also called positive-skew distributions. That’s because there is a long tail in the positive direction on the number line. The mean is also to the right of the peak.

A left-skewed distribution has a long left tail. Left-skewed distributions are also called negatively-skewed distributions. That’s because there is a long tail in the negative direction on the number line. The mean is also to the left of the peak.

EFFECT  ON MEAN, MEDIAN AND MODE DUE TO SKEWNESS:

In the case of negative skew, the mean is influenced by the presence of outliers at the lower end of the data’s range. This means that the mean would be less than the median and mode. It seems counterintuitive that the majority of the data is on the higher side, but it is called negative skew. One mnemonic that I use is that the long tail points to the negative side of an x-axis.

For positive skew, the case is backward. The mean is heavily influenced by the outliers at the upper part of the data’s range. In this case, the mean is greater than the mode or median. The mnemonic that I use is that the long tail is skewed toward the positive end of the x-axis.

QQ PLOT:
When the quantiles of two variables are plotted against each other, then the plot obtained is known as quantile – quantile plot or qqplot. This plot provides a summary of whether the distributions of two variables are similar or not with respect to the locations.


BOX COX:
A Box Cox transformation is a transformation of a non-normal dependent variables into a normal shape. Normality is an important assumption for many statistical techniques; if your data isn’t normal, applying a Box-Cox means that you are able to run a broader number of tests.

